import os
from os import getenv
from dotenv import load_dotenv

if os.path.exists("local.env"):
    load_dotenv("local.env")

load_dotenv()
admins = {}
SUPPORT = getenv("SUPPORT", "TrickyAbhii_Op")
