<h1 align="center"><b>Tricky-Music</b></h1>


# down
  <details>
<summary><b>🔗 Session String</b></summary>
<br>

> You'll need a [API_ID](https://my.telegram.org/auth) & [API_HASH](https://my.telegram.org/auth) in order to generate pyrogram session string. 
> Always remember to use good API combo else your account could be deleted.

<h4> Generate Session via Repl.it: </h4>    
<p><a href="https://replit.com/@SJMxADITI/TrickyAbhi-Music?lite=1&outputonly=1#main.py"><img src="https://img.shields.io/badge/Generate%20On%20Repl-blueviolet?style=for-the-badge&logo=appveyor" width="350""/></a></p>

</details>

  
  
# Deployments
  
### Heroku Deployment
  
  [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://herox-xd.github.io/Am-Noob/)
  
  
###  Okteto Deployment

<h4>Click the button below to deploy on Okteto!</h4>
<a href="https://cloud.okteto.com/deploy?repository=https://github.com/SJMxADITI/TrickyAbhi-Music"><img src="https://img.shields.io/badge/Deploy%20To%20Okteto-informational?style=for-the-badge&logo=Okteto" width="250""/></a>

  

  
# TrickyAbhi-Music
OMFO Gimme a star and follow me 
  
  
  
### Noob Developers 
  
 <a href="https://github.com/AnonymousR1025"><img src="https://img.shields.io/badge/pro%20 Anonymous-ReD.svg?style=for-the-badge&logo=Python"></a> 

<a href="https://t.me/herox_xd"><img src="https://img.shields.io/badge/Noob%20 Herox-ReD.svg?style=for-the-badge&logo=Python"></a> 
  
  <a href="https://t.me/ABHIISH3K_xD"><img src="https://img.shields.io/badge/Piro%20 Abhishek-Green.svg?style=for-the-badge&logo=Python"></a>
## Support & Updates 
<a href="https://t.me/TrickyAbhii_Op"><img src="https://img.shields.io/badge/Join-Group%20Support-blue.svg?style=for-the-badge&logo=Telegram"></a> <a href="https://t.me/Techno_Trickop"><img src="https://img.shields.io/badge/Join-Updates%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
  
# Join crow frnd 
  
  
- Click Here 👇🏻 And join pls 
  
  [![Herox](https://telegra.ph/file/39e17ab3a96207d3e15ac.jpg)](https://t.me/aboutez)
